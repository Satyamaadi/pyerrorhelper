from .manager import ErrorManager    

__all__ = ["ErrorManager"]

__version__ = "0.0.1"